-- phpMyAdmin SQL Dump
-- version 5.1.2
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Nov 25, 2024 at 02:48 PM
-- Server version: 5.7.24
-- PHP Version: 8.3.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `studybuds`
--

-- --------------------------------------------------------

--
-- Table structure for table `contact_us`
--

CREATE TABLE `contact_us` (
  `id` int(11) NOT NULL,
  `name` varchar(30) NOT NULL,
  `gender` varchar(10) NOT NULL,
  `mobile` varchar(20) NOT NULL,
  `dob` date NOT NULL,
  `email` varchar(60) NOT NULL,
  `language` varchar(20) NOT NULL,
  `message` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `contact_us`
--

INSERT INTO `contact_us` (`id`, `name`, `gender`, `mobile`, `dob`, `email`, `language`, `message`, `created_at`) VALUES
(1, 'Layan Hosam Kandil', 'female', '+966557859333', '2004-03-06', 'lulukandil@gmail.com', 'arabic', 'i need help asap, thankyou', '2024-11-19 20:11:24');

-- --------------------------------------------------------

--
-- Table structure for table `groups`
--

CREATE TABLE `groups` (
  `id` int(11) NOT NULL,
  `name` varchar(30) NOT NULL,
  `subject` varchar(50) NOT NULL,
  `schedule` varchar(30) NOT NULL,
  `description` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `groups`
--

INSERT INTO `groups` (`id`, `name`, `subject`, `schedule`, `description`, `created_at`) VALUES
(13, 'Games', 'technology', 'Friday at 5PM', 'for breaks and fun', '2024-11-21 23:42:55'),
(14, 'StudyBuds Team', 'technology', 'wensday at 7PM', 'for StudyBuds Team', '2024-11-23 23:36:44'),
(15, 'Cybers', 'technology', 'Friday at 7PM', 'for CTF ', '2024-11-23 23:37:18'),
(16, 'WEB DEVELOPMENT', 'technology', 'Friday at 7PM', 'to study WEB DEVELOPMENT ', '2024-11-23 23:38:31'),
(17, 'Creative Expressions', 'art', 'monday 11PM', 'to explore various art forms, including painting, drawing, and digital art. This group is perfect for artists of all levels who want to enhance their skills, share techniques, and collaborate on projects', '2024-11-23 23:41:40'),
(18, 'CyberGroup', 'technology', 'Sunday 6pm', 'Cyber security subjects study group', '2024-11-25 12:02:05');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(30) NOT NULL,
  `username` varchar(30) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `bio` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `username`, `email`, `password`, `bio`) VALUES
(24, 'maryam', 'mrym0', 'mrym9ci@gmail.com', '$2b$10$31/CXUx0V/QA2u2pYn2jxemRwsMtnJNckBLK8z/.IL5yI9qGEhBLm', 'cyber security student'),
(26, 'nadia ', 'nadia11', 'nadia@gmail.com', '$2b$10$Vzapmf4jMHPxsIuBh50knOBNH9QDS4E4oY4s6i2dWKG2nVajZx7LC', ''),
(34, 'Layan kandil', 'lay24', 'layankandil@gmail.com', '$2b$10$8x/QaM6FE7UalEei37rrxu8L7spCncFY9oP.rHCS7mQhRH7fOvoYi', 'passionate cybersecurity student '),
(35, 'mashaer', 'mesho12', 'mashaerald6@kau.edu.sa', '$2b$10$EyAwiiZQ5WZpQ2gt/Etsmew1zG1r6S5kepCAw4je6QbBi59D6l.Wm', 'Art student '),
(38, 'deema alshehri', 'demo23', 'dem@hotmail.com', '$2b$10$lSOVIs3CUwlqVwfx0FloQ.Fgzy1Si/l9Q341qlNeBvd1o0ALo5EYq', '');

-- --------------------------------------------------------

--
-- Table structure for table `user_groups`
--

CREATE TABLE `user_groups` (
  `user_id` int(11) NOT NULL,
  `group_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `user_groups`
--

INSERT INTO `user_groups` (`user_id`, `group_id`) VALUES
(24, 13),
(24, 15),
(34, 17);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `contact_us`
--
ALTER TABLE `contact_us`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `groups`
--
ALTER TABLE `groups`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unique_group_name` (`name`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `user_groups`
--
ALTER TABLE `user_groups`
  ADD PRIMARY KEY (`user_id`,`group_id`),
  ADD KEY `group_id` (`group_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `contact_us`
--
ALTER TABLE `contact_us`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `groups`
--
ALTER TABLE `groups`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=39;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `user_groups`
--
ALTER TABLE `user_groups`
  ADD CONSTRAINT `user_groups_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `user_groups_ibfk_2` FOREIGN KEY (`group_id`) REFERENCES `groups` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
