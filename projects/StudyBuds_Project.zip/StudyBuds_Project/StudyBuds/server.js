const express = require('express');
const mysql = require('mysql2');
const bodyParser = require('body-parser');
const path = require('path');
const bcrypt = require('bcrypt'); // For password hashing

const app = express();
const port = 2500;

// Middleware
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true })); // To parse URL-encoded bodies
app.use('/CSS', express.static(path.join(__dirname, 'CSS'))); // Serve CSS files
app.use('/MEDIA', express.static(path.join(__dirname, 'MEDIA'))); // Serve media files
app.use('/HTML', express.static(path.join(__dirname, 'HTML'))); // Serve HTML files

// Serve the homepage
app.get("/", (req, res) => {
    res.sendFile(path.join(__dirname, 'HTML', 'index.html')); // Path to index.html
});

// MySQL connection
const pool = mysql.createPool({
    host: 'localhost',
    user: 'root', // Replace with your actual DB username
    password: 'root', // Replace with your actual DB password
    database: 'studybuds', // Your database name
    port: 3306, // Default MySQL port
});

// User Signup
app.post('/signup', (req, res) => {
    const { name, username, email, password, bio } = req.body;

    // Server-side validation
    if (!name || name.length < 5 || name.length > 30 || !/^[A-Za-z\s]+$/.test(name)) {
        return res.status(400).json({ message: "Full name must be between 5 and 30 characters and can only contain letters and spaces." });
    }

    if (!username || username.length < 4 || username.length > 30) {
        return res.status(400).json({ message: "Username must be between 4 and 30 characters." });
    }

    const emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
    if (!email || !emailRegex.test(email)) {
        return res.status(400).json({ message: "Please enter a valid email address." });
    }

    if (!password || password.length < 6 || !/(?=.*[a-z])(?=.*[A-Z])(?=.*\d)/.test(password)) {
        return res.status(400).json({ message: "Password must be at least 6 characters long and contain at least one uppercase letter, one lowercase letter, and one number." });
    }

    // Hash the password before storing it
    bcrypt.hash(password, 10, (err, hash) => {
        if (err) {
            console.error("Error hashing password:", err);
            return res.status(500).json({ message: "Internal server error \n" + err });
        }
        
        const query = "INSERT INTO users (name, username, email, password, bio) VALUES (?, ?, ?, ?, ?)";
        pool.query(query, [name, username, email, hash, bio], (error) => {
            if (error) {
                console.error("Error inserting user:", error);
                return res.status(500).json({ message: "Error signing up: \n" + error });
            }
            res.status(200).json({ message: "User registered successfully" });
        });
    });
});

// User Login
app.post('/login', (req, res) => {
    const { username, password } = req.body;

    // Server-side validation
    if (!username || username.length < 4 || username.length > 15) {
        return res.status(400).json({ message: "Username must be between 4 and 15 characters." });
    }

    if (!password || password.length < 6) {
        return res.status(400).json({ message: "Password must be at least 6 characters long." });
    }

    const query = "SELECT * FROM users WHERE username = ?";
    pool.query(query, [username], (error, results) => {
        if (error) {
            console.error("Error retrieving user:", error);
            return res.status(500).json({ message: "Error logging in: \n" + error });
        }
        if (results.length === 0) {
            return res.status(401).json({ message: "Invalid username or password" });
        }

        const user = results[0];
        bcrypt.compare(password, user.password, (err, match) => {
            if (err) {
                console.error("Error comparing passwords:", err);
                return res.status(500).json({ message: "Internal server error: \n" + err });
            }
            if (!match) {
                return res.status(401).json({ message: "Invalid username or password" });
            }

            // Send user ID and success message back
            res.json({
                status: 'success',
                message: 'Login successful',
                user_id: user.id // This is important, ensure user_id is sent back
            });
        });
    });
});

// Fetch user profile
app.get("/user-profile/:userId", (req, res) => {
    const userId = req.params.userId;
    const query = "SELECT name, email, bio FROM users WHERE id = ?";
    pool.query(query, [userId], (error, results) => {
        if (error) {
            console.error("Error retrieving user profile:", error);
            return res.status(500).send("Error retrieving user profile: \n" + error);
        }
        if (results.length === 0) {
            return res.status(404).send("User not found");
        }
        res.json(results[0]);
    });
});

// Fetch user groups
app.get("/user-groups/:userId", (req, res) => {
    const userId = req.params.userId;
    const query = `
        SELECT g.id, g.name, g.subject, g.schedule, g.description
        FROM groups g
        JOIN user_groups ug ON g.id = ug.group_id
        WHERE ug.user_id = ?`;
    pool.query(query, [userId], (error, results) => {
        if (error) {
            console.error("Error retrieving user groups:", error);
            return res.status(500).send("Error retrieving user groups: \n" + error);
        }
        res.json(results);
    });
});


// Create a new group
app.post("/create-group", (req, res) => {
    const { name, subject, schedule, description } = req.body;

    // Server-side validation
    if (!name || name.length < 3 || name.length > 30 || !/^[A-Za-z0-9\s]+$/.test(name)) {
        return res.status(400).json({ message: "Group name must be between 3 and 30 characters and can only contain letters, numbers, and spaces." });
    }

    if (!subject) {
        return res.status(400).json({ message: "Subject is required." });
    }

    if (!schedule || schedule.length < 5 || schedule.length > 30 || !/^[A-Za-z0-9\s,]+$/.test(schedule)) {
        return res.status(400).json({ message: "Schedule must be between 5 and 30 characters and can only contain letters, numbers, spaces, and commas." });
    }

    if (!description || description.length < 5 || description.length > 50) {
        return res.status(400).json({ message: "Description must be between 5 and 50 characters." });
    }

    // Check if the group name already exists
    const checkQuery = "SELECT * FROM groups WHERE name = ?";
    pool.query(checkQuery, [name], (checkError, results) => {
        if (checkError) {
            console.error("Error checking group name:", checkError);
            return res.status(500).json({ message: "Internal server error while checking group name." });
        }

        if (results.length > 0) {
            return res.status(400).json({ message: "Group name is already in use." });
        }

        // If the group name is unique, proceed to insert
        const insertQuery = "INSERT INTO groups (name, subject, schedule, description, created_at) VALUES (?, ?, ?, ?, NOW())";
        pool.query(insertQuery, [name, subject, schedule, description], (insertError) => {
            if (insertError) {
                console.error("Error inserting group:", insertError);
                return res.status(500).json({ message: "Error creating group: " + insertError.message });
            }
            res.status(201).json({ message: "Group created successfully" });
        });
    });
});

// Fetch available groups
app.get("/available-groups", (req, res) => {
    const interest = req.query.interest;
    let query = "SELECT * FROM groups";
    if (interest && interest !== "all") {
        query += " WHERE subject = ?";
    }
    pool.query(query, [interest], (error, results) => {
        if (error) {
            console.error("Error retrieving groups:", error);
            return res.status(500).send("Error retrieving groups: \n"+ error);
        }
        res.json(results);
    });
});

// Join a group
app.post("/join-group", (req, res) => {
    const { userId, groupId } = req.body;

    if (!userId || !groupId) {
        return res.status(400).json({ message: 'Missing userId or groupId' });
    }

    const query = "INSERT INTO user_groups (user_id, group_id) VALUES (?, ?)";
    pool.query(query, [userId, groupId], (error) => {
        if (error) {
            console.error("Error joining group:", error);
            return res.status(500).json({ message: 'Error joining group: \n'+ error });
        }
        res.json({ message: 'Successfully joined the group' });
    });
});


// Leave a group
app.post("/leave-group", (req, res) => {
    const { userId, groupId } = req.body;
    const query = "DELETE FROM user_groups WHERE user_id = ? AND group_id = ?";
    pool.query(query, [userId, groupId], (error) => {
        if (error) {
            console.error("Error leaving group:", error);
            return res.status(500).send("Error leaving group: \n"+error);
        }
        res.send("Successfully left the group");
    });
});

// Contact Us Form Submission Route
app.post('/submit-contact', (req, res) => {
    const { name, gender, mobile, dob, email, language, message } = req.body;

    // Validation
    const errorMessages = [];

    // Validate Name
    if (!name || name.length < 2 || name.length > 30 || !/^[A-Za-z\s]+$/.test(name)) {
        errorMessages.push("Name must be 2-30 characters and can only contain letters and spaces.");
    }

    // Validate Gender
    if (!gender || (gender !== 'male' && gender !== 'female')) {
        errorMessages.push("Gender must be selected as Male or Female.");
    }

    // Validate Mobile Number
    const mobilePattern = /^\+9665[0-9]{8}$/;
    if (!mobilePattern.test(mobile)) {
        errorMessages.push("Please enter a valid mobile number (e.g., +966512345678).");
    }

    // Validate Date of Birth
    const birthDate = new Date(dob);
    const today = new Date();
    const age = today.getFullYear() - birthDate.getFullYear();
    const monthDiff = today.getMonth() - birthDate.getMonth();
    if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < birthDate.getDate())) {
        age--;
    }
    if (age < 15) {
        errorMessages.push("You must be older than 15 years old.");
    }

    // Validate Email
    const emailPattern = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
    if (!emailPattern.test(email)) {
        errorMessages.push("Please enter a valid email address.");
    }

    // Validate Language
    if (!language || (language !== 'arabic' && language !== 'english')) {
        errorMessages.push("Preferred language must be selected.");
    }

    // Validate Message
    if (!message || message.length === 0 || message.length > 250) {
        errorMessages.push("Message is required and cannot exceed 250 characters.");
    }

    // If there are validation errors, send them back
    if (errorMessages.length > 0) {
        return res.status(400).json({ message: errorMessages.join(", ") }); // Send back error messages
    }

    // Prepare SQL query
    const query = `INSERT INTO contact_us (name, gender, mobile, dob, email, language, message) VALUES (?, ?, ?, ?, ?, ?, ?)`;

    // Insert into database
    pool.query(query, [name, gender, mobile, dob, email, language, message], (error, results) => {
        if (error) {
            console.error('Error inserting contact message:', error);
            return res.status(500).json({ message: 'Error submitting message: ' + error });
        }
        res.status(200).json({ message: 'Message submitted successfully' });
    });
});

// Start server
app.listen(port, () => {
    console.log(`Server is running at http://localhost:${port}`);
});