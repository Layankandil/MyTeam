/*
Layan Kandil	2210192
Maryam Alotaibi	2212708
Deema Alshehri	2211090
Section : D31
OOP2 Project 
*/

package RideNGo;

import java.awt.*;
import java.awt.event.*;
import java.util.Random;
import javax.swing.*;

public class ReservationWindow extends JFrame{
    
    private Students student;
    private JPanel panel;
    private JPanel panel2;
    private JPanel ScooterPanel;
    private JPanel GolfPanel;
    private JLabel label;
    private JComboBox vehiclesComboBox;
    private JButton okButton;
    private JRadioButton time1Button;
    private JRadioButton time2Button;
    private JRadioButton time3Button;
    private JRadioButton time4Button;
    private JRadioButton time5Button;
    private JRadioButton time6Button;
    private JRadioButton time7Button;
    final int WINDOW_WIDTH = 400;
    final int WINDOW_HEIGHT = 250;
    final ImageIcon scooterImage = new ImageIcon("scooter.png");
    final ImageIcon golfImage = new ImageIcon("golf.png");
    
    public ReservationWindow(){
        
        setTitle("Vehicle reservation");
        setSize(WINDOW_WIDTH,WINDOW_HEIGHT);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                
        bulidPanel();
        add(panel);

        setLocationRelativeTo(null);
        setVisible(true);
    }
    
    public void setStudent(Students student){
        this.student = new Students(student);
    }
    
    private void bulidPanel() {
        
        panel = new JPanel();
        panel2 = new JPanel();
        
        panel.setBackground(new Color(255,185,85,16));
        panel2.setBackground(new Color(255,185,85,16));
        panel2.setBorder(BorderFactory.createTitledBorder("Choice"));
        
        label = new JLabel("What kind of vehicle would you like to rent?");
        label.setFont(new Font("Serif",Font.ITALIC,16));
        
        String[] vehicles = {"Scooter","Golf car (one trip)","Golf car (two way trip)"};
        vehiclesComboBox = new JComboBox(vehicles);
        vehiclesComboBox.setFont(new Font("Serif",Font.ITALIC,16));
        vehiclesComboBox.addActionListener(new vehiclesComboBoxListener());
                
        panel.add(label);
        panel2.add(vehiclesComboBox);
        panel.add(panel2);
        
    }
    
    private class vehiclesComboBoxListener implements ActionListener{

        @Override
        public void actionPerformed(ActionEvent e) {
            
            /* in this method we will remove the previous panel 
            that was asking the user to choose a vehicle 
            and then display another panel based on the users choice 
            */
            
            int index = vehiclesComboBox.getSelectedIndex();
            
            if(index == 0){
                
                remove(panel);
                setTitle("Scooter reservation ");
                
                ScooterPanel = new JPanel(new GridLayout(6,0));
                panel = new JPanel();
                
                label = new JLabel("Please choose the Scooter reservation time you need : "
                        ,scooterImage , SwingConstants.CENTER);
                label.setFont(new Font("Serif",Font.ITALIC + Font.BOLD,16));
                
                time1Button = new JRadioButton("(1) : pick up 8am return 10 am");
                time1Button.setMnemonic(KeyEvent.VK_1);
                time1Button.setFont(new Font("Serif",Font.ITALIC,16));
                time2Button = new JRadioButton("(2) : pick up 10am return 12 pm");
                time2Button.setMnemonic(KeyEvent.VK_2);
                time2Button.setFont(new Font("Serif",Font.ITALIC,16));
                time3Button = new JRadioButton("(3) : pick up 12pm return 2 pm");
                time3Button.setMnemonic(KeyEvent.VK_3);
                time3Button.setFont(new Font("Serif",Font.ITALIC,16));
                time4Button = new JRadioButton("(4) : pick up 2pm return 4 pm");
                time4Button.setMnemonic(KeyEvent.VK_4);
                time4Button.setFont(new Font("Serif",Font.ITALIC,16));
                
                okButton = new JButton("OK");
                okButton.setMnemonic(KeyEvent.VK_ENTER);
                okButton.addActionListener(new ScooterButtonListener());
                panel.add(okButton);
                
                ButtonGroup bg = new ButtonGroup();
                bg.add(time1Button);
                bg.add(time2Button);
                bg.add(time3Button);
                bg.add(time4Button);
                
                ScooterPanel.setBackground(new Color(255,237,208));
                label.setBackground(new Color(254,237,208));
                time1Button.setBackground(new Color(253,237,208));
                time2Button.setBackground(new Color(252,237,208));
                time3Button.setBackground(new Color(251,237,208));
                time4Button.setBackground(new Color(250,237,208));
                panel.setBackground(new Color(250,237,208));
                
                ScooterPanel.add(label);
                ScooterPanel.add(time1Button);
                ScooterPanel.add(time2Button);
                ScooterPanel.add(time3Button);
                ScooterPanel.add(time4Button);
                ScooterPanel.add(panel);
                                
                add(ScooterPanel);
                setSize(450,375);
                setLocationRelativeTo(null);
                validate();
            }
            
            else if(index ==1){
                remove(panel);
                setTitle("Golf reservation ");
                
                GolfPanel = new JPanel(new GridLayout(9,0));
                GolfPanel.setBackground(new Color(255,237,208));
                panel = new JPanel();
                panel.setBackground(new Color(250,237,208));
                
                label = new JLabel("please choose the golf ride time you need:"
                        , golfImage , SwingConstants.LEFT);
                label.setFont(new Font("Serif",Font.ITALIC + Font.BOLD,16));
                
                time1Button = new JRadioButton("(1) : pick up time 8 am");
                time1Button.setMnemonic(KeyEvent.VK_1);
                time1Button.setBackground(new Color(255,237,208));
                time1Button.setFont(new Font("Serif",Font.ITALIC,16));
                time2Button = new JRadioButton("(2) : pick up time 9 am");
                time2Button.setMnemonic(KeyEvent.VK_2);
                time2Button.setBackground(new Color(254,237,208));
                time2Button.setFont(new Font("Serif",Font.ITALIC,16));
                time3Button = new JRadioButton("(3) : pick up time 10 am");
                time3Button.setMnemonic(KeyEvent.VK_3);
                time3Button.setBackground(new Color(254,237,208));
                time3Button.setFont(new Font("Serif",Font.ITALIC,16));
                time4Button = new JRadioButton("(4) : pick up time 11 am");
                time4Button.setMnemonic(KeyEvent.VK_4);
                time4Button.setBackground(new Color(253,237,208));
                time4Button.setFont(new Font("Serif",Font.ITALIC,16));
                time5Button = new JRadioButton("(5) : pick up time 12 pm");
                time5Button.setMnemonic(KeyEvent.VK_5);
                time5Button.setBackground(new Color(252,237,208));
                time5Button.setFont(new Font("Serif",Font.ITALIC,16));
                time6Button = new JRadioButton("(6) : pick up time 1 pm");
                time6Button.setMnemonic(KeyEvent.VK_6);
                time6Button.setBackground(new Color(251,237,208));
                time6Button.setFont(new Font("Serif",Font.ITALIC,16));
                time7Button = new JRadioButton("(7) : pick up time 2 pm");
                time7Button.setMnemonic(KeyEvent.VK_7);
                time7Button.setBackground(new Color(250,237,208));
                time7Button.setFont(new Font("Serif",Font.ITALIC,16));
                
                okButton = new JButton("OK");
                okButton.setMnemonic(KeyEvent.VK_ENTER);
                okButton.addActionListener(new Golf1ButtonListener());
                panel.add(okButton);
                
                ButtonGroup bg = new ButtonGroup();
                bg.add(time1Button);
                bg.add(time2Button);
                bg.add(time3Button);
                bg.add(time4Button);
                bg.add(time5Button);
                bg.add(time6Button);
                bg.add(time7Button);

                GolfPanel.add(label);
                GolfPanel.add(time1Button);
                GolfPanel.add(time2Button);
                GolfPanel.add(time3Button);
                GolfPanel.add(time4Button);
                GolfPanel.add(time5Button);
                GolfPanel.add(time6Button);
                GolfPanel.add(time7Button);
                GolfPanel.add(panel);
                                
                add(GolfPanel);
                setSize(450,375);
                setLocationRelativeTo(null);
                validate();
            }
            else // if(index ==2)
            {
                remove(panel);
                setTitle("Golf reservation ");
                
                GolfPanel = new JPanel(new GridLayout(7,0));
                GolfPanel.setBackground(new Color(250,237,208));
                panel = new JPanel();
                panel.setBackground(new Color(250,237,208));
                
                label = new JLabel("please choose the golf reservation time you need:"
                        , golfImage , SwingConstants.LEFT);
                time1Button = new JRadioButton("(1) First trip : 8:00AM and Second trip : 9:00AM");
                time1Button.setMnemonic(KeyEvent.VK_1);
                time1Button.setBackground(new Color(250,237,208));
                time1Button.setFont(new Font("Serif",Font.ITALIC,16));
                time2Button = new JRadioButton("(2) First trip : 9:00AM and Second trip : 10:00AM");
                time2Button.setMnemonic(KeyEvent.VK_2);
                time2Button.setBackground(new Color(250,237,208));
                time2Button.setFont(new Font("Serif",Font.ITALIC,16));
                time3Button = new JRadioButton("(3) First trip : 10:00AM and Second trip : 11:00AM");
                time3Button.setMnemonic(KeyEvent.VK_3);
                time3Button.setBackground(new Color(250,237,208));
                time3Button.setFont(new Font("Serif",Font.ITALIC,16));
                time4Button = new JRadioButton("(4) First trip : 11:00AM and Second trip : 12:00PM");
                time4Button.setMnemonic(KeyEvent.VK_4);
                time4Button.setBackground(new Color(250,237,208));
                time4Button.setFont(new Font("Serif",Font.ITALIC,16));
                time5Button = new JRadioButton("(5) First trip : 1:00PM and Second trip : 2:00PM");
                time5Button.setMnemonic(KeyEvent.VK_5);
                time5Button.setBackground(new Color(250,237,208));
                time5Button.setFont(new Font("Serif",Font.ITALIC,16));
                
                okButton = new JButton("OK");
                okButton.setMnemonic(KeyEvent.VK_ENTER);
                okButton.addActionListener(new Golf2ButtonListener());
                panel.add(okButton);
                                
                ButtonGroup bg = new ButtonGroup();
                bg.add(time1Button);
                bg.add(time2Button);
                bg.add(time3Button);
                bg.add(time4Button);
                bg.add(time5Button);
                
                GolfPanel.add(label);
                GolfPanel.add(time1Button);
                GolfPanel.add(time2Button);
                GolfPanel.add(time3Button);
                GolfPanel.add(time4Button);
                GolfPanel.add(time5Button);
                GolfPanel.add(panel);
                
                setLayout(new BorderLayout());
                                
                add(GolfPanel);
                setSize(450,375);
                setLocationRelativeTo(null);
                validate(); 
            }
        }
    }
    
    private class Golf1ButtonListener implements ActionListener{

        @Override
        public void actionPerformed(ActionEvent e) {
            
                int tripChoice=0;
                
                if(time1Button.isSelected())
                    tripChoice=1;
                else if(time2Button.isSelected())
                    tripChoice=2;
                else if(time3Button.isSelected())
                    tripChoice=3;
                else if(time4Button.isSelected())
                    tripChoice=4;
                else if(time5Button.isSelected())
                    tripChoice=5;
                else if(time6Button.isSelected())
                    tripChoice=6;
                else if(time7Button.isSelected())
                    tripChoice=7;
                
                Golf golf = new Golf("One Trip.");
                student.bookVehicle(golf, tripChoice);
                setVisible(false);
                new printWindow(student.toString());
        }
    }
    
    private class Golf2ButtonListener implements ActionListener{

        @Override
        public void actionPerformed(ActionEvent e) {
            
                int tripChoice=0;
                
                if(time1Button.isSelected())
                    tripChoice=8;
                else if(time2Button.isSelected())
                    tripChoice=9;
                else if(time3Button.isSelected())
                    tripChoice=10;
                else if(time4Button.isSelected())
                    tripChoice=11;
                else if(time5Button.isSelected())
                    tripChoice=12;
                
                Golf golf = new Golf("two way Trip.");
                student.bookVehicle(golf, tripChoice);
                setVisible(false);
                new printWindow(student.toString());
        }
    }
    
    private class ScooterButtonListener implements ActionListener{

        @Override
        public void actionPerformed(ActionEvent e) {
            
                //array that holds scooter objects 
                Scooter[] scooter = new Scooter[5]; 
        
                //create scooter objects in the array 
                for(int i=0; i<5; i++){
                    scooter[i]=new  Scooter (i+1);
                }
                
                // set a random scooter number
                Random random = new Random();
                int scooter_number = random.nextInt(5);
                int tripChoice=0;
                
                if(time1Button.isSelected())
                    tripChoice=1;
                else if(time2Button.isSelected())
                    tripChoice=2;
                else if(time3Button.isSelected())
                    tripChoice=3;
                else if(time4Button.isSelected())
                    tripChoice=4;
                
                student.bookVehicle(scooter[scooter_number], tripChoice);
                setVisible(false);
                new printWindow(student.toString());
        }
    }
}
