/*
Layan Kandil	2210192
Maryam Alotaibi	2212708
Deema Alshehri	2211090
Section : D31
OOP2 Project 
*/

package RideNGo;

/*custom exception class for our project 
    we used it in the signinWindow calss */

public class dataException extends Exception {

    public dataException(String error) {
        
        super("Error : "+error);        
     
    }
    
}
