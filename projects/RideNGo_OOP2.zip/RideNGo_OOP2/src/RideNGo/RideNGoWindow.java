/*
Layan Kandil	2210192
Maryam Alotaibi	2212708
Deema Alshehri	2211090
Section : D31
OOP2 Project 
*/

package RideNGo;


import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class RideNGoWindow extends JFrame {
   
    private JMenu fileMenu;
    private JMenuBar menuBar;            
    private JMenu helpMenu;  
    private JMenuItem exitItem;
    private JMenuItem colorItem;
    private JMenuItem contactItem;
    private JPanel panel;
    private JPanel panel2;
    private JPanel panel3;
    private JPanel ImagePanel;
    private JLabel label;
    private JRadioButton loginButton;
    private JRadioButton signinButton;
    private JButton StartButton;
    private JButton okButton;
    final int WINDOW_WIDTH = 550;
    final int WINDOW_HEIGHT = 475;
    final ImageIcon logo = new ImageIcon("RideNGo.jpg");
    
    public RideNGoWindow(){
        
        setTitle("RideNGo");
        setSize(WINDOW_WIDTH,WINDOW_HEIGHT);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
       
        setLayout(new GridLayout(4,1));
        
        buildMenuBar();
        bulidPanel();
        
        add(ImagePanel);
        add(panel);
        add(panel2);
        add(panel3);
        setLocationRelativeTo(null);
        setVisible(true);    
       
    }
    
    private void bulidPanel() {
        panel = new JPanel();
        panel2 = new JPanel();
        panel3 = new JPanel();
        ImagePanel = new JPanel();
        
        panel.setBackground(new Color(255,185,85,16));
        panel2.setBackground(new Color(255,185,85,16));
        panel3.setBackground(new Color(255,185,85,16));
        ImagePanel.setBackground(new Color(0,50,50,236));
        
        label = new JLabel("", logo ,SwingConstants.LEFT);
        ImagePanel.add(label);
        
        label = new JLabel("Welcome to RideNGo Application!!");
        panel.add(label);
        label.setFont(new Font("Serif",Font.ITALIC + Font.BOLD,24));
        
        label = new JLabel("<html>This application allows you to book a ride"
                + " <br>to get to your college as fast as possible.</html>");
        panel2.add(label);
        label.setFont(new Font("Serif",Font.ITALIC + Font.BOLD,20));
      
        StartButton = new JButton("Start");
        StartButton.setMnemonic(KeyEvent.VK_ENTER);
        StartButton.setFont(new Font("Serif",Font.ITALIC + Font.BOLD,20));
        StartButton.addActionListener(new StartButtonListener());
        
        panel3.add(StartButton);
        
    }
      
    private void buildMenuBar() { 
          
        menuBar = new JMenuBar();  
        buildFileMenu();  
        buildHelpMenu(); 
              
        menuBar.add(fileMenu); 
        menuBar.add(helpMenu);
              
        setJMenuBar(menuBar);    
    }
    
    private void buildFileMenu() { 
          
        exitItem = new JMenuItem("Exit");  
        exitItem.setMnemonic(KeyEvent.VK_E);  
        exitItem.addActionListener(new ExitListener()); 
        
        colorItem = new JMenuItem("Change Background");
        colorItem.setMnemonic(KeyEvent.VK_C);  
        colorItem.addActionListener(new colorListener()); 
      
        fileMenu = new JMenu("File");   
        fileMenu.setMnemonic(KeyEvent.VK_F); 
        fileMenu.add(exitItem);
        fileMenu.addSeparator();  
        fileMenu.add(colorItem);
    }
    
    private void buildHelpMenu() { 
          
        contactItem = new JMenuItem("Contact Support");  
        contactItem.setMnemonic(KeyEvent.VK_S);  
        contactItem.addActionListener(new SupportListener());  
      
        helpMenu = new JMenu("Help");   
        helpMenu.setMnemonic(KeyEvent.VK_H); 
        helpMenu.add(contactItem);  
    }
    
    private class ExitListener implements ActionListener   { 
        @Override
        public void actionPerformed(ActionEvent e)      { 
            System.exit(0); 
        } 
    }
    
    private class colorListener implements ActionListener   { 
        @Override
        public void actionPerformed(ActionEvent e)      { 
            Color selectedColor  = JColorChooser.showDialog(null, 
                "Select a BackGround Color", Color.WHITE);
            panel.setBackground(selectedColor);
            panel2.setBackground(selectedColor);
            panel3.setBackground(selectedColor);         
        } 
    }
    
    private class SupportListener implements ActionListener   { 
        @Override
        public void actionPerformed(ActionEvent e)      { 
            JOptionPane.showMessageDialog(null, "For support please contact :"
                    + "\nRideNGo.support@gmail.com"); 
        } 
    }
    
    private class StartButtonListener implements ActionListener {
    @Override
    public void actionPerformed(ActionEvent e) {
        
            /* in this method we will remove the previous  welcome panel 
            from the main frame and add a new panel that will 
            ask the student if they want to log in or sign in
            */
            
        remove(panel);
        remove(panel2);
        remove(panel3);
         
        panel2 = new JPanel();
        panel3 = new JPanel();
        panel= new JPanel();
        
        panel.setBackground(new Color(255,185,85,16));
        panel2.setBackground(new Color(255,185,85,16));
        panel3.setBackground(new Color(255,185,85,16));
        
        JLabel chooseLabel = new JLabel("Please choose from the following:");
        chooseLabel.setFont(new Font("Serif", Font.ITALIC + Font.BOLD, 20));
        panel2.add(chooseLabel);
        loginButton = new JRadioButton("Login");
        loginButton.setFont(new Font("Serif", Font.ITALIC + Font.BOLD, 17));
        loginButton.setMnemonic(KeyEvent.VK_L);
        loginButton.setToolTipText("(𝘴𝘦𝘦 𝘺𝘰𝘶𝘳 𝘱𝘳𝘦𝘷𝘪𝘰𝘶𝘴 𝘳𝘦𝘴𝘦𝘳𝘷𝘢𝘵𝘪𝘰𝘯)");
         
        signinButton = new JRadioButton("Signin");
        signinButton.setFont(new Font("Serif", Font.ITALIC + Font.BOLD, 17));
        signinButton.setMnemonic(KeyEvent.VK_S);
        signinButton.setToolTipText("(𝘔𝘢𝘬𝘦 𝘢 𝘯𝘦𝘸 𝘳𝘦𝘴𝘦𝘳𝘷𝘢𝘵𝘪𝘰𝘯)");
        ButtonGroup group = new ButtonGroup();
        group.add(loginButton);
        group.add(signinButton);
   
        panel3.add(loginButton);
        panel3.add(signinButton);
        
        okButton = new JButton("ok");
        okButton.setToolTipText("click to move");
        okButton.setMnemonic(KeyEvent.VK_ENTER);
        okButton.setFont(new Font("Serif", Font.ITALIC + Font.BOLD, 18));
        okButton.addActionListener(new OkButtonListener());
        panel.add(okButton);
        add(panel2);
        add(panel3);
        add(panel);
        setSize(WINDOW_WIDTH-5,WINDOW_HEIGHT-5);
        validate();
                  
    }
    }
  
     
    private class OkButtonListener implements ActionListener{
       
        @Override
        public void actionPerformed(ActionEvent e) {
           
            if(loginButton.isSelected()){
               setVisible(false);
               new LoginWindow();
            }
            
            else if (signinButton.isSelected()){
                setVisible(false);
                new SigninWindow();
            } 
        }    

    }
    
    public static void main (String[] args){
        new RideNGoWindow();
            
    }

}
                
