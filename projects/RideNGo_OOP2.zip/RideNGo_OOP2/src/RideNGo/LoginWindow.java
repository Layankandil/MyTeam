/*
Layan Kandil	2210192
Maryam Alotaibi	2212708
Deema Alshehri	2211090
Section : D31
OOP2 Project 
*/

package RideNGo;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;


public class LoginWindow extends JFrame{
    
    private JPanel panel;
    private JPanel panel2;
    private JPanel panel3;
    private JLabel label;
    private JTextField idTextField;
    private JTextField passwordTextField;
    private JButton logButton;
    final int WINDOW_WIDTH = 450;
    final int WINDOW_HEIGHT = 375;
    
    public LoginWindow(){
        setTitle("Login");
        setSize(WINDOW_WIDTH,WINDOW_HEIGHT);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        setLayout(new GridLayout(3,0));
        
        bulidPanel();
        add(panel);
        add(panel2);
        add(panel3);
        
        setLocationRelativeTo(null);
        setVisible(true);
    }
    
    private void bulidPanel() {
        panel = new JPanel();
        panel2 = new JPanel();
        panel3 = new JPanel();
        
        panel.setBackground(new Color(255,185,85,16));
        panel2.setBackground(new Color(255,185,85,16));
        panel3.setBackground(new Color(255,185,85,16));

        label = new JLabel("Student ID : ");
        label.setFont(new Font("Serif",Font.ITALIC,18));
        idTextField= new JTextField(10);
        panel.add(label);
        panel.add(idTextField);
        
        label = new JLabel("Student Password : ");
        label.setFont(new Font("Serif",Font.ITALIC,18));
        passwordTextField= new JTextField(10);
        panel2.add(label);
        panel2.add(passwordTextField);
        
        logButton = new JButton("Log in");
        logButton.setFont(new Font("Serif", Font.ITALIC + Font.BOLD, 13));
        logButton.setMnemonic(KeyEvent.VK_ENTER);
        logButton.addActionListener(new logButtonListener());
        
        panel3.add(logButton);
    }
    
    private class logButtonListener implements ActionListener{

        @Override
        public void actionPerformed(ActionEvent e) {
                String password = passwordTextField.getText();
                Students showReservation = new Students(idTextField.getText());
                
                //call checkPassword method to check the student password
                boolean flag = showReservation.checkPassword(password);

                //give the user 3 trys to enter a wrong password
                for (int i =1;flag==false;i++){
                    
                    if (i==3){
                        JOptionPane.showMessageDialog(null,"\nSorry maximum limit has been reached"
                        +"\nthe app will now terminate.\n", "Error", JOptionPane.ERROR_MESSAGE);
                        //terminate the app
                        System.exit(0);
                    }
                    
                    password = JOptionPane.showInputDialog("\nthe password you entered is wrong, please try again."
                            + "\nEnter the password : ");
                    flag = showReservation.checkPassword(password);
                    
                }// end for loop
                
                //call to the readFile method to read from students file
                String str = showReservation.readFile();
                setVisible(false);
                //JOptionPane.showMessageDialog(null,str + 
                   // "\nThank you for using RideNGo\nHave a nice Day!\n");
                //System.exit(0);
                new printWindow(str);
        }
    }

}
