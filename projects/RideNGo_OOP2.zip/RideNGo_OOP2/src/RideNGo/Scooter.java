/*
Layan Kandil	2210192
Maryam Alotaibi	2212708
Deema Alshehri	2211090
Section : D31
OOP2 Project 
*/

package RideNGo;

// The purpose of this class is to reserve a Scooter for the student

public class Scooter extends Vehicles 
{
    private int Scooter_number; //the scooter's number
    private String tripTime; //the time of trip
    private String vehicle_type; // the type of vehicle that the student choose
    private int price; // the price of the vehicle
    
    
    
    /**
     * Constructor initializes the Scooter_number ,
 vehicle_type and price.
     * 
     * @param ScooterNum the number of the scooter
     */
    
    public Scooter( int ScooterNum){
        
        Scooter_number = ScooterNum;  //set the Scooter_number
        
        vehicle_type= "Scooter number "+ Scooter_number ; //set vehicle type
        
        price = 20; //set the vehicle price
        
        //set the vehicle trip time
        tripTime= "pick up 8:00AM - return 10:00AM";
        
    }//end Constructor
    
    
    
    /**
     * the copy constructor initializes the object 
     * as a copy of another Scooter object 
     * @param object2 the object to copy
     */
    
    public Scooter(Scooter object2){
        
        tripTime= object2.tripTime; //copy the tripTime field
        
        vehicle_type = object2.vehicle_type; //copy the vehicle_type field
        
        price = object2.price; //copy the price field
        
    }//end Constructor
    
    
    
    /**
     * no parameter Constructor that initializes the Scooter_number ,
     * vehicle_type and price.
     * 
     */
    
    public Scooter(){
        
        Scooter_number = 0;
        
        vehicle_type= "Scooter number "+ Scooter_number ;
        
        price = 20; //set the vehicle price
        
        //set the vehicle trip time
        tripTime= "pick up 8:00AM - return 10:00AM";
        
    }//end Constructor
    
    
    
    /**
     * the ScooterTrip method sets a value for tripTime field.
     * @param tripChoice the trip time choice of the student 
     */
    
    public void ScooterTrip(int tripChoice){
        
        //switch the student trip time choice to set the triptime field
        switch(tripChoice){ 
             case 1:
                 tripTime= "pick up 8:00AM - return 10:00AM";
                 break;
                  
             case 2: 
                 tripTime = "pick up 10:00AM - return 12:00PM";
                 break;
                 
             case 3: 
                 tripTime = "pick up 12:00AM - return 2:00PM";
                 break;
                 
             case 4: 
                 tripTime = "pick up 2:00AM - return 4:00PM";
                 break;
                 
       }//end switch
        
        //call the setTrip method of this class and send the tripTime as an argument 
        setTrip(tripTime);

    }//end setTrip method
    
    
    
    /**
     * the setTrip method sets a value for tripTime field.
     * @param trip_time the trip time of the student.
     */
    
       public void setTrip(String trip_time){
       
       tripTime = trip_time;

    }//end setTrip method
    
 
 
    /**
     * the setScooter_number method sets a value for Scooter_number field.
     * @param Scooter_number the number of the scooter. 
     */
 
    public void setScooter_number(int Scooter_number) {
        
        this.Scooter_number = Scooter_number;
        
    }//end setScooter_number method
 
 
    
    /**
     * the setVehicle_type method sets a value for vehicle_type field.
     * @param vehicle_type the type of vehicle. 
     */
 
    public void setVehicle_type(String vehicle_type) {
        this.vehicle_type = vehicle_type + "number " + Scooter_number;
        
    }//end setVehicle_type method
 
    
 
    /**
     * the setScooterPrice method sets a value for price field.
     * @param price the price of the vehicle. 
     */
 
    public void setScooterPrice(int price) {
        
        this.price = price;

    }//end setScooterPrice method
 
    
    
    /**
    * getScooter_number method
    * @return the scooter number.
    */
    
    public int getScooter_number() {
        
        return Scooter_number;
        
    }//end getScooter_number method

   
    
    /**
     * getTrip method
     * @return the triptime details of the student.
     */
    
    public String getTrip() {
        
        return tripTime;
        
    }//end getTrip method

    
    
    /**
     * getVehicle_type method
     * @return the vehicle type choosen.
     */
    
    public String getVehicle_type() {
        
        return vehicle_type;
        
    }//end getVehicle_type method

    
  
    /**
     * getScooterPrice method
     * @return the scooter's price.
     */
    
    public int getScooterPrice() {
        
        return price;
        
    }//end getScooterPrice method

    
    
    /**
     * toString method
     * @return str a string containing the supercalss toString method.
     */
    @Override
    public String toString(){

        //call a supercalss toString method and save its value in str variable       
        String str = super.toString();
                
        //return the string
        return str;
        
    }//end toString method
    
}//end scooter class

