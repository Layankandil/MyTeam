/*
Layan Kandil	2210192
Maryam Alotaibi	2212708
Deema Alshehri	2211090
Section : D31
OOP2 Project 
*/

package RideNGo;

/* This class takes the user information via text fields and a list 
   and then send them to the reservation window 
*/

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class SigninWindow extends JFrame{
    private JLabel Name_label;
    private JLabel ID_label;
    private JLabel phone_label;
    private JLabel College_label;
    private JLabel paasword_label;
    private JTextField Name_field;
    private JTextField ID_field;
    private JTextField phone_field;
    private JTextField paasword_field;
    private JList collegeList;
    private JScrollPane scroll;
    private JButton signButton;
    private JPanel panel1;
    private JPanel panel2;
    private JPanel panel3;
    private JPanel panel4;
    private JPanel panel5;
    private JPanel panel6;
    final int WINDOW_WIDTH = 550;
    final int WINDOW_HEIGHT = 475;
    
    public SigninWindow(){
        setTitle("Signin");
        setSize(WINDOW_WIDTH,WINDOW_HEIGHT);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        setLayout(new GridLayout(6,1));
        
        bulidPanel();
        add(panel1);
        add(panel2);
        add(panel3);
        add(panel4);
        add(panel5);
        add(panel6);
        
        setLocationRelativeTo(null);
        setVisible(true);
    }
    
    private void bulidPanel() {
        panel1 = new JPanel();
        panel2 = new JPanel();
        panel3 = new JPanel();
        panel4 = new JPanel();
        panel5 = new JPanel();
        panel6 = new JPanel();
        
        panel1.setBackground(new Color(255,185,85,16));
        panel2.setBackground(new Color(255,185,85,16));
        panel3.setBackground(new Color(255,185,85,16));
        panel4.setBackground(new Color(255,185,85,16));
        panel5.setBackground(new Color(255,185,85,16));
        panel6.setBackground(new Color(255,185,85,16));
        
        String[] colleges = {"(1) Holy Quran and Islamic Studies",
            "(2) Business","(3) Computer Science and Engineering",
            "(4) Science","(5) Medicine",
            "(6)  Applied Medical Sciences",
            "(7) English Language Institute",
            "(8) Art and Design", "(9) Social Sciences ",
            "(10) Law and Judicial Studies" , "(11) Sport Sciences" ,
            "(12) Communication and Media", "(13) Languages and Translation "};
        
        collegeList = new JList(colleges);
        collegeList.setFont(new Font("Serif",Font.ITALIC,14));
        collegeList.setVisibleRowCount(3);
        scroll = new JScrollPane(collegeList);
        
        Name_label = new JLabel(" Student Name : ");
        Name_label.setFont(new Font("Serif",Font.ITALIC,18));
        ID_label = new JLabel("Student ID : ");
        ID_label.setFont(new Font("Serif",Font.ITALIC ,18));
        phone_label = new JLabel("Phone Number : ");
        phone_label.setFont(new Font("Serif",Font.ITALIC,18));
        College_label = new JLabel("College : ");
        College_label.setFont(new Font("Serif",Font.ITALIC ,18));
        paasword_label = new JLabel("Student Password : ");
        paasword_label.setFont(new Font("Serif",Font.ITALIC ,18));
                
        Name_field= new JTextField(10);
        ID_field= new JTextField(10);
        phone_field= new JTextField(10);
        paasword_field= new JTextField(10);
        
        signButton = new JButton("Sign in");
        signButton.setMnemonic(KeyEvent.VK_ENTER);
        signButton.addActionListener(new signButtonListener());
        
        panel1.setLayout(new FlowLayout(FlowLayout.CENTER));
        panel2.setLayout(new FlowLayout(FlowLayout.CENTER));
        panel3.setLayout(new FlowLayout(FlowLayout.CENTER));
        panel4.setLayout(new FlowLayout(FlowLayout.CENTER));
        panel5.setLayout(new FlowLayout(FlowLayout.CENTER));
        panel6.setLayout(new FlowLayout(FlowLayout.CENTER));
        
        
        panel1.add(Name_label);
        panel1.add(Name_field);
        
        panel2.add(ID_label);
        panel2.add(ID_field);
        
        panel3.add(phone_label);
        panel3.add(phone_field);
        
        panel4.add(paasword_label);
        panel4.add(paasword_field);
        
        panel5.add(College_label);
        panel5.add(scroll);
        
        panel6.add(signButton);

    }


    private class signButtonListener implements ActionListener {
    @Override
    public void actionPerformed(ActionEvent e) {
        if (Name_field.getText().isEmpty() || ID_field.getText().isEmpty() || phone_field.getText().isEmpty() || paasword_field.getText().isEmpty()) {
            JOptionPane.showMessageDialog(null, "Please fill in all fields.", "Error", JOptionPane.ERROR_MESSAGE);
        }
        else{  
                try {
                    int id = Integer.parseInt(ID_field.getText());
                     if (ID_field.getText().length() !=  7) {
                    JOptionPane.showMessageDialog(null, "Invalid input for ID. Exactly 7 digits allowed.", "Error", JOptionPane.ERROR_MESSAGE);
                     return;
                     }
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(null, "Invalid input for ID. Only digits are allowed.", "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }
                try {
                    long number = Integer.parseInt(phone_field.getText())+'L';
                    String phonum= phone_field.getText();
                    if (phonum.length() != 10 || phonum.charAt(0)!='0' || phonum.charAt(1)!='5' )
                     {
                        throw new NumberFormatException();
                     }
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(null, "Invalid input for phone number."
                            + "\n\nmake sure that only digits are entered"
                            + "\n\nand that the number starts with 05"
                            + "\n\nand that exactly 10 digits are entered",
                            "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }
                
                // .* matches any sequence of characters (including zero characters).
                //\\d+ matches one or more numeric digits.
                //.* again matches any sequence of characters
                try {
                    if (Name_field.getText().matches(".*\\d+.*")) {
                        //using our custom exception class
                        throw new dataException( "Invalid input for name. Only alphabetic characters are allowed.");
                    }
                }
                catch(dataException se){
                    JOptionPane.showMessageDialog(null, se.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                try {
                    if(collegeList.getSelectedIndex()==-1){
                        //using our custom exception class
                        throw new dataException( "Please Choose your college.");
                    }
                }
                catch(dataException ce){
                    JOptionPane.showMessageDialog(null, ce.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }
                
                String college = (String)collegeList.getSelectedValue();
                Students student = new Students(Name_field.getText(),
                        ID_field.getText(),phone_field.getText(), 
                        paasword_field.getText(),college);
                
                setVisible(false);
                ReservationWindow reservation =new ReservationWindow();
                reservation.setStudent(student);
              }
         }
      }
   }

