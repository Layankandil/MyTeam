/*
Layan Kandil	2210192
Maryam Alotaibi	2212708
Deema Alshehri	2211090
Section : D31
OOP2 Project 
*/

package RideNGo;

import java.io.*;
import java.util.Scanner;
import javax.swing.JOptionPane;

/*
   This class defines a student by name , id , phone number and college. 
   Students class holds data about the student choosen vehicle. 
   and lastly it saves the student info and choosen vehicle info in a 
   srudent file that is protected by a password.
*/


public class Students {
    private String Student_name; //student's first name 
    private String id_number; //student's id number
    private String phone_number; //student's phone number
    private String college; //student's college
    private String Student_password; //hold the student reservation password
    private Vehicles vehicle; //object of type Vehicles that hold the vehicle information
    private Scooter scooter; //object of type Scooter that hold the scooter information
    private Golf golf; //object of type Golf that hold the golf information
    private String fileName; //hold the student's file name
    private PrintWriter file; // prinwriter file to save student info
    private File StudentFile; //student's file

    
    
    /**
     * Constructor initializes the first_name ,last_name ,id_number
     * phone_number , fileName , file , and Student_password.
     * @param Student_n the student's name
     * @param id the student's id number
     * @param phoneNum the student's phone number
     * @param Password the student reservation password
     * @param Student_college
     */
    
    public Students(String Student_n ,  String id, String phoneNum,
    String Password , String Student_college){
        
        Student_name = Student_n;
        id_number = id;
        phone_number = phoneNum;
        Student_password = Password;
        college = Student_college;
        fileName = id_number+".txt"; //initallize the student file name
        
        try{
            //open file
            file = new PrintWriter (fileName); 
        }
        catch(FileNotFoundException e){
            JOptionPane.showMessageDialog(null, "\nError opening "
                    + "the file in students construcor\n", "Error", JOptionPane.ERROR_MESSAGE);
        }
        
    }//end constructor
    
    
    
    /**
     * no param Constructor that initializes the first_name ,last_name ,
     * id_number , phone_number , college and Student_password.
     */
    public Students(){
        
        Student_name = "";
        id_number = "";
        phone_number = "";
        college = "";
        Student_password ="";
        
    }//end constructor
    
    
    
    /**
     * Constructor initializes the id_number ,fileName ,
     *and open a StudentFile.
     * @param id the student's id number
     */
    public Students(String id) 
    {
       
       id_number=id;
       fileName = id_number+".txt"; //initallize the file name
       
       try{
       //open file
       StudentFile = new File(fileName); 
       }
       catch(Exception e){
           JOptionPane.showMessageDialog(null,e.getMessage());
       }
       
    }//end constructor
    
    
    
    /**
     * the copy constructor initializes the object 
     * as a copy of another Students object 
     * @param object2 the object to copy
     */
    
    public Students(Students object2){
        
        Student_name= object2.Student_name;
        id_number = object2.id_number;
        phone_number = object2.phone_number;
        college = object2.college;
        Student_password = object2.Student_password;
        vehicle = object2.vehicle;
        scooter = object2.scooter;
        golf = object2.golf;
        fileName = object2.fileName;
        file = object2.file;
        StudentFile = object2.StudentFile;
        
    }//end Constructor

    
    
    /** the bookVehicle method 
     * allows the student to book a vehicle of type Scooter
     * @param scooter is an object of kind scooter to be copied
     * @param tripChoice the number of trip time that student choose.
     */
    public void bookVehicle(Scooter scooter,int tripChoice){
        
        /*creat a new scooter object , passing a scooter object as an argument 
        to copy the object */ 
        this.scooter=new Scooter(scooter);
        
        //call the ScooterTrip method of the Scooter object to set the trip time
        this.scooter.ScooterTrip(tripChoice);
        
        /*call the inherited setprice ,setVehicle and setTripTime
        methods to set the vehicle information in the parent class.*/
        this.scooter.setprice(this.scooter.getScooterPrice());
        this.scooter.setTripTime(this.scooter.getTrip());
        this.scooter.setVehicle(this.scooter.getVehicle_type());
        
        /*creat a Vehicles "parent class" object , 
        passing a Scooter "child class" as an argument 
        to copy the objecta data */
        vehicle= new Vehicles(this.scooter);
        
    }//end bookVehicle method
    
    
    
    /** the bookVehicle method 
     * allows the student to book a vehicle of type Golf
     * @param golf is an object of kind Golf to be copied
     * @param tripChoice the number of trip time that student choose.
     */
    public void bookVehicle(Golf golf , int tripChoice){
        
        /*creat a new Golf object , passing a golf object as an argument 
        to copy the object */
        this.golf = new Golf(golf);
        
        //call the golfTrip method of the golf object to set the trip time
        this.golf.golfTrip(tripChoice);
        
        //call the GolfPrice method of the golf object set the price
        this.golf.GolfPrice(tripChoice);
        
        /*call the inherited setprice ,setVehicle and setTripTime
        methods to set the vehicle information in the parent class.*/
        this.golf.setprice(this.golf.getGolfPrice());
        this.golf.setTripTime(this.golf.getTrip());
        this.golf.setVehicle(this.golf.getVehicle_type());

        /*creat a Vehicles "parent class" object , 
        passing a Golf "child class" as an argument 
        to copy the objects data */
        vehicle = new Vehicles(this.golf);
        
    }//end bookVehicle method

    
    
    /** the no param readFile method 
     * it makes sure that the student file exist then scan the file and print it
     * if it does not exist it prints a message then terminate the app.
     * @return 
     */
    public String readFile() //throws IOException 
    {
        String fileContents="";
   
        //if (StudentFile.exists()){ //validating the file existance
        try{  
            // create new scanner object that reads from the file 
            Scanner ReadFile  = new Scanner(StudentFile);

            
            // create a while loop to read the file and print it until EOF
            while(ReadFile.hasNext()){
                String str = ReadFile.nextLine();
                 
                // to skip printing the student's file password
                if (str.equals(Student_password)){
                    continue;
                }
                 
                fileContents= fileContents + str + "\n"; 
                 
            }//end while
             
            //close the file 
            ReadFile.close();
            
        }//end if 
       
       //else { //if(!(StudentFile.exists())) 
        catch(FileNotFoundException e){
             JOptionPane.showMessageDialog(null,"\nSorry, There was no reservation found under this ID."
                            + "\nPlease re-start the application to make a new reservation.\n", "Error", JOptionPane.ERROR_MESSAGE);
             //terminate the application
             System.exit(0); 
       }// end else 
       
        return fileContents;
    }//end readFile method
    
    
    
    /**checkPassword method 
     * it makes sure that the student file exist then verify that the student
     * entered the correct password for the file
     * if the file does not exist it prints a message then terminate the app.
     * @param password Student file password
     * @return true if the password is correct 
     */
    public boolean checkPassword(String password) //throws IOException
    {
        
        // the password entered by the student
        Student_password = password ; 
        
        //validating the file existance
        //if (StudentFile.exists()){
        try{  
            // create new scanner object that reads from the file 
            Scanner ReadFile = new Scanner(StudentFile);
            
            
            /* create a while loop to do a sequential search  
            and read the file until EOF to verify the student file password */
            
            while(ReadFile.hasNext()){
                String str = ReadFile.nextLine();
                
                /*compare the file line to the search value
                and return true if the password is correct */
                if (str.equals(Student_password)){
                return true;
                }
            }// end while loop
            
            //close file
            ReadFile.close();

        }// end if (StudentFile.exists())
       
        //else { //if(!(StudentFile.exists()))
        catch(FileNotFoundException e){
            JOptionPane.showMessageDialog(null,"\nSorry, There was no reservation found under this ID."
                + "\nPlease re-start the application to make a new reservation.\n", "Error", JOptionPane.ERROR_MESSAGE);
            //terminate the application
            System.exit(0);
        }
        
        // if the student file password was not found in the file
        return false;
       
    }// end checkPassword method  
    
    
    
    /**
     * the setFile method open a file with the fileName of the student.
     * @throws java.io.IOException
     */
    public void setFile()throws IOException{
        
        //open file
        file = new PrintWriter (fileName);
        
    }//end setFile method
    

    /**
     * the setFileName method sets a value for fileName field.
     * @param id the student's id number. 
     */
    public void setFileName(String id) {
        
        fileName = id+".txt";
        
    }//end setFileName method


    
    /**
     * the setStudentFile method sets a value for StudentFile field.
     * @param StudentFile the student's file. 
     */
    
    public void setStudentFile(File StudentFile) {
        
        //open file
        this.StudentFile = new File(fileName);
        
    }//end setStudentFile method

    
    
    /**
     * the setVehicles method sets a value for vehicle field.
     * @param vehicle the vehicle object that will be copied
     */
    
    public void setVehicle(Vehicles vehicle) {
        
        /*creat a vehicle object , passing a vehicle as an argument 
        to the copy constructor*/
        this.vehicle = new Vehicles(vehicle);
        
    }//end setVehicles method.

    
    
    /**
     * the setScooter method sets a value for scooter field.
     * @param scooter the Scooter object that will be copied  
     */
    
    public void setScooter(Scooter scooter) {
        
        /*creat a scooter object , passing a scooter as an argument 
        to the copy constructor*/
        this.scooter = new Scooter(scooter);
        
    }//end setScooter method.
    
    
    
    /**
     * the setGolf method sets a value for golf field.
     * @param golf the Golf object that will be copied
     */
    public void setGolf(Golf golf) {
        
        /*creat a golf object , passing a golf as an argument 
        to the copy constructor*/
        this.golf = new Golf(golf);
        
    }//end setGolf method.
    
    
    
    /**
     * the setStudent_name method sets a value for first_name field.
     * @param name the student's name. 
     */
    public void setStudent_name(String name) {
        
        Student_name = name;
        
    }//end setStudent_name method.
     
    
    /**
     * the setId_number method sets a value for id_number field.
     * @param id_number the student's id number. 
     */
    
    public void setId_number(String id_number) {
        
        this.id_number = id_number;
        
    }//end setId_number method
    
    
    
    /**
     * the setPhone_number method sets a value for phone_number field.
     * @param phone_number the student's id number. 
     */
    public void setPhone_number(String phone_number) {
        
        this.phone_number = phone_number;
        
    }//end setPhone_number method

    
    
    /**
     * the setStudent_password method sets a value for Student_password field.
     * @param Student_password the student's file password. 
     */
    public void setStudent_password(String Student_password) {
        this.Student_password = Student_password;
    }
    
    /**
     * the setCollege method sets a value for college field.
     * @param college the students college 
     */
    public void setCollege(String college) {
        this.college = college;
    }
    
    
    /**
     * getFile method
     * @return file the PrintWriter of the file
     */
    public PrintWriter getFile() {
        return file;
        
    }// end getFile method

    
    
    /** 
     * getFileName method
     * @return fileName the file name
     */
    
    public String getFileName() {
        return fileName;
        
    }//end getFileName method

    
    
    /** 
     * getStudentFile method
     * @return StudentFile the student's file
     */
    
    public File getStudentFile() {
        return StudentFile;
        
    }//end getStudentFile method


    
   /** 
     * getVehicles method
     * @return a copy of vehicle 
     */
    
    public Vehicles getVehicle() {
        
        return new Vehicles(vehicle);
        
    }//end getVehicles method
    
    
    
    /** 
     * getScooter method
     * @return a copy of scooter 
     */
    
    public Scooter getScooter() {
        
        return new Scooter(scooter);
        
    }//end getScooter method

    
    
    /** 
     * getGolf method
     * @return a copy of golf 
     */
    
    public Golf getGolf() {
        return new Golf(golf);
        
    }//end getGolf method

    
    
    /** 
     * getFirst_name method
     * @return first_name the student's first name
     */
    
    public String getStudent_name() {
        return Student_name;
        
    }//end getFirst_name method  
    
    /** 
     * getId_number method
     * @return id_number the student's id number
     */
    public String getId_number() {
        return id_number;
        
    }//end getId_number method

    
    
    /** 
     * getPhone_number method
     * @return phone_number the student's phone number .
     */
    
    public String getPhone_number() {
        return phone_number;
        
    }//end getPhone_number method

    
    
    /** 
     * getStudent_password method
     * @return Student_password the student's file password .
     */
    
    public String getStudent_password() {
        return Student_password;
    }

    
    
    /** 
     * getCollege method
     * @return college the student's college.
     */
    
    public String getCollege() {
        return college;
        
    }//end getCollege method
    
    
    
    /**
     * toString method
     * @return str A string containing the reservation information 
     */
    @Override
    public String toString()
    {
        // Create a string describing the reservation.
        String str = "\n\nYour reservation : " +
            "\n\nThe Student information : " +
            "\nStudens Name : " + Student_name +
            "\nUser ID : " + id_number + 
            "\nPhone number : "+ phone_number +
            "\nCollege : "+ college +
            "\n"+ vehicle ;

        
        //save the reservation details + the file password to the file
        String inFile = str + "\n\n" + Student_password;
        //print the reservation information and file password in the studentfile
        file.println(inFile);
 
        //close file
        file.close();
         
        // Return the string.
        return str;
        
        }//end toString method 
    
    }//end class


