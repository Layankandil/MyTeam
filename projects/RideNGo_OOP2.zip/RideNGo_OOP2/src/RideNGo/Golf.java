/*
Layan Kandil	2210192
Maryam Alotaibi	2212708
Deema Alshehri	2211090
Section : D31
OOP2 Project 
*/

package RideNGo;

// The purpose of this class is to reserve a Golf car for the student

public class Golf extends Vehicles 
{
    private String tripTime; //the time of trip
    private String golf_path; //the trip type of golf that user choose 
    private String vehicle_type; // the type of vehicle that user choose
    private int price; // the price of the trip
    
    
    /**
     * Constructor initializes the  golf_path , vehicle_type
     * price and tripTime.
     * @param golfPath the golf path of golf that the student choose
     */
    
    public Golf(String golfPath){
        
        this.golf_path = golfPath;
        
        //set the vehicle price
        price = 5;
        
        //set the vehicle type 
        vehicle_type= "Golf car " + golf_path;
        
        //set the vehicle trip time
        tripTime= "pick up is at 8:00AM";
        
    }//end Constructor 
    
    
    /**
     * the copy constructor initializes the object 
     * as a copy of another Scooter object 
     * @param object2 the object to copy
     */
    
    public Golf(Golf object2){
        tripTime= object2.tripTime;
        vehicle_type = object2.vehicle_type;
        price = object2.price;
    }//end Constructor
    
    
    
    /**
     * no parameter Constructor initializes the golf_path, vehicle_type
     * price and tripTime.
     */
    
    public Golf(){
        
        golf_path = "";
        
        price = 0;
        
        //set the vehicle type 
        vehicle_type= "Golf car " + golf_path;
        
        //set the vehicle trip time
        tripTime= "no trip";
        
    }//end Constructor
    
    
    
    /**
     * the golfTrip method sets a value for tripTime field.
     * @param tripChoice the trip time choice of the student.
     */
    public void golfTrip(int tripChoice){
        
        //switch the student trip time choice to set the triptime field
       switch(tripChoice){
             case 1:
                 tripTime= "pick up is at 8:00AM";
                 break;
      
             case 2: 
                 tripTime = "pick up is at 9:00AM";
                 break;
             
             case 3: 
                 tripTime = "pick up is at 10:00AM";
                 break;
             
             case 4: 
                 tripTime = "pick up is at 11:00AM";
                 break;
             
             case 5:
                 tripTime= "pick up is at 12:00PM";
                 break;
             
             case 6: 
                 tripTime = "pick up is at 1:00PM";
                 break;
             
             case 7: 
                 tripTime = "pick up is at 2:00PM";
                 break;
             
             case 8: 
                 tripTime = "First trip is at : 8:00AM" +
                            "\nSecond trip is at : 9:00AM" ;
                 break;
             
             case 9:
                 tripTime= "First trip is at : 9:00AM" +
                            "\nSecond trip is at : 10:00AM" ;
                 break;
             
             case 10: 
                 tripTime = "First trip is at : 10:00AM" +
                            "\nSecond trip is at : 11:00AM" ;
                 break;
             
             case 11: 
                 tripTime = "First trip is at : 11:00AM" +
                            "\nSecond trip is at : 12:00AM" ;
                 break;
             
             case 12: 
                 tripTime = "First trip is at : 1:00PM" +
                            "\nSecond trip is at : 2:00PM" ;
                 break;  
       }//end switch
       
       //call the setTrip method of this class and send the tripTime as an argument 
       setTrip(tripTime);
       
    }//end golfTrip method
    
    
    
    /**
     * the GolfPrice method sets a value for price field.
     * @param tripChoice the student choice from the trip time menu. 
     */
    
    public void GolfPrice(int tripChoice) {
        
        //sets the value of price.
        if (tripChoice >=1 && tripChoice<=7){
            price = 5;
        }//end if
        
        else if (tripChoice>=8 && tripChoice<=12){
            price = 10;
        }// end else
        
        //call the setGolfPrice method and send the price as an argument
        setGolfPrice(price);
        
    }//end GolfPrice method
    
    
    
    /**
     * the setTrip method sets a value for tripTime field.
     * @param trip_time the trip time of the student.
     */
    
    public void setTrip(String trip_time){
       
       tripTime = trip_time;

    }//end setTrip method
   
    

    /**
     * the setGolf_path method sets a value for golf_path field.
     * @param golf_path the golf path that the student choose. 
     */
    public void setGolf_path(String golf_path) {
        
        this.golf_path = golf_path;
        
    }//end setGolf_path method
    
    
    
    /**
     * the setVehicle_type method sets a value for vehicle_type field.
     * @param vehicle_type the type of vehicle. 
     */
    public void setVehicle_type(String vehicle_type) {
        
        this.vehicle_type = vehicle_type + getGolf_path();
        
    }//end setVehicle_type method
    
    
    
    /**
     * the setGolfPrice method sets a value for price field.
     * @param golfPrice the cost required from the user for the golf car. 
     */
    
    public void setGolfPrice(int golfPrice) {
        
        price = golfPrice;
        
    }//end setGolfPrice method
    

 
    /**
     * getTrip method
     * @return the trip time that student choose.
     */
    public String getTrip() {
        
        return tripTime;
        
    }//end getTrip method

    
    
    /**
     * getGolf_path method
     * @return the golf path of the student.
     */
    
    public String getGolf_path() {
        
        return golf_path;
        
    }//end getGolf_path method

    
    
    /**
     * getVehicle_type method
     * @return the type of vehicle.
     */
    
    public String getVehicle_type() {
        
        return vehicle_type;
        
    }//end getVehicle_type method

    
    
    /**
     * getGolfPrice method
     * @return the golf's price.
     */
    
    public int getGolfPrice() {
        
        return price;
        
    }//end getGolfPrice method

    
    
    /**
     * toString method
     * @return a string containing the supercalss toString method.
     */
    
    @Override
    public String toString(){
        
        //call a supercalss toString method and save its value in str variable       
        String str =  super.toString();
        
        //return the string
        return str;
        
    }//end toString method
    
}//end class


