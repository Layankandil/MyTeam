/*
Layan Kandil	2210192
Maryam Alotaibi	2212708
Deema Alshehri	2211090
Section : D31
OOP2 Project 
*/

package RideNGo;

/*
   This class prints the reservation details in a window 
    and then the ending image
*/

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class printWindow extends JFrame{
    private JTextArea reservation;
    private JPanel panel1;
    private JPanel panel2;
    private JLabel Image;
    private JButton done;
    final int WINDOW_WIDTH = 450;
    final int WINDOW_HEIGHT = 375;
    
    public printWindow(String str){
        
        setTitle("Reservation details");
        setSize(WINDOW_WIDTH,WINDOW_HEIGHT);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        reservation = new JTextArea();
        reservation.setEditable(false);
        reservation.setText(str);
        reservation.setBackground(new Color(255,185,85,16));
        reservation.setFont(new Font("Serif", Font.ITALIC + Font.BOLD, 15));
        
        done = new JButton("Done");
        done.setMnemonic(KeyEvent.VK_ENTER);
        done.addActionListener(new DoneButtonListener()); 
        done.setFont(new Font("Serif", Font.ITALIC + Font.BOLD, 13));
        
        panel1=new JPanel();
        panel2=new JPanel();
        panel1.setBackground(new Color(255,185,85,16));
        panel2.setBackground(new Color(255,185,85,16)); 
        panel1.add(reservation);
        panel2.add(done);
       
        add(panel1, BorderLayout.CENTER);
        add(panel2, BorderLayout.SOUTH);
        
        setLocationRelativeTo(null);
        setVisible(true);
    }
    
    private class DoneButtonListener implements ActionListener{

        @Override
        public void actionPerformed(ActionEvent e) {
            
            /* removing the reservation details panel 
             and add the panel with the ending image */
            
            remove(panel1);
            remove(panel2);
            ImageIcon welcome = new ImageIcon("welcome2.jpg");
         
            Image=new JLabel();
            Image.setIcon(welcome);
         
            add(Image);
         
            pack();
            setLocationRelativeTo(null);
            validate();  
            
        }
    }
}
