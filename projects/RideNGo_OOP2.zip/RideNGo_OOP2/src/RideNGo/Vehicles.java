/*
Layan Kandil	2210192
Maryam Alotaibi	2212708
Deema Alshehri	2211090
Section : D31
OOP2 Project 
*/

package RideNGo;

/* The purpose of this class is to save a vehicle information:
 vehicle tripTime , vehicle_type, and price.
 Classes representing specific vehicles should inherit from this class.*/

public class Vehicles {
    private String tripTime; //the time of trip
    private String vehicle_type; // the type of vehicle that the student choose
    private int price; // the price of the vehicle
     
 
    /**
     * Constructor initializes the tripTime ,vehicle_type ,
     * and price fields.
     * @param tripTime the time of trip
     * @param vehicle_type the type of vehicle
     * @param price the price of the vehicle
     */
    public Vehicles(String tripTime, String vehicle_type, int price) {
        
        this.tripTime = tripTime;
        this.vehicle_type = vehicle_type;
        this.price = price;
        
    }//end Constructor
    
    
    
    /**
     * the copy constructor initializes the object 
     * as a copy of another Vehicle object 
     * @param object2 the object to copy
     */
    
    public Vehicles(Vehicles object2){
        
        tripTime= object2.tripTime;
        vehicle_type = object2.vehicle_type;
        price = object2.price;
        
    }//end Constructor
    
    
    
    /**
     * no parameter Constructor that initializes the tripTime ,vehicle_type ,
     * and price.
     */
    
    public Vehicles(){
        
        this("","",0);
        
    }//end Constructor
    
    
    
    /**
     * the setTripTime method sets a value for tripTime field.
     * @param timetrip the trip time details. 
     */
    
    public void setTripTime(String timetrip){
    
        this.tripTime = timetrip;
        
    }//end setTripTime method
    
    
    
    /**
     * the setVehicle method sets a value for vehicle_type field.
     * @param type the choosen vehicle type. 
     */
    
    public void setVehicle(String type){
        vehicle_type = type;
        
    }//end setVehicle method
    
    
    
    /**
     * the setPrice method sets a value for price field.
     * @param vehicleprice the price of the vehicle. 
     */
     public void setprice(int vehicleprice){
        price = vehicleprice;
        
    }//end setPrice method
     
     
     
    /** 
     * getprice method
     * @return price the price of the vehicle
     */
     
     public int getprice(){
        return price ;
        
    }//end getprice method
     
     
     
    /** 
     * getvehicle_type method
     * @return vehicle_type the type of the vehicle
     */
     
     public String getvehicle_type(){
        return   vehicle_type ;
        
    }//end getvehicle_type method
     
     
     
    /** 
     * gettriptime method
     * @return tripTime the trip time
     */
     
     public String gettriptime(){
        return tripTime ;
        
    }//end gettriptime method
    
     
     
    /**
     * toString method
     * @return str A string containing the vehicle information 
     */
     @Override
    public String toString(){
        
        // Create a string that holds the vehicle details.
        String str= "\nTrip details : \n" + tripTime +
                "\nVehicle reserved: " + vehicle_type +
                    "\nCost required : " + price + "SR" ;
       
        // Return the string.
        return str;
        
    }//end toString method
     
}//end class



